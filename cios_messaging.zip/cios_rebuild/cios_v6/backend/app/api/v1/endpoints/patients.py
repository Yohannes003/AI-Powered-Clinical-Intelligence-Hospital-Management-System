from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

from app.db.session import get_db
from app.core.security import get_current_user
from app.core.permissions import require_permission, Permission
from app.services.patient_service import PatientService
from app.services.ai_service import AIService
from app.audit.audit_service import AuditService

router = APIRouter(prefix="/patients", tags=["Patients"])


class PatientCreate(BaseModel):
    full_name: str
    date_of_birth: datetime
    gender: str
    blood_type: Optional[str] = None
    contact_phone: Optional[str] = None
    contact_email: Optional[str] = None
    address: Optional[str] = None
    emergency_contact: Optional[dict] = None
    allergies: Optional[List[str]] = []
    chronic_conditions: Optional[List[str]] = []
    current_medications: Optional[List[str]] = []
    insurance_info: Optional[dict] = None
    ward: Optional[str] = None
    bed_number: Optional[str] = None
    attending_doctor_id: Optional[int] = None
    status: str = "active"


class VitalSignCreate(BaseModel):
    temperature: Optional[float] = None
    heart_rate: Optional[int] = None
    systolic_bp: Optional[int] = None
    diastolic_bp: Optional[int] = None
    respiratory_rate: Optional[int] = None
    oxygen_saturation: Optional[float] = None
    blood_glucose: Optional[float] = None
    weight: Optional[float] = None
    height: Optional[float] = None
    gcs_score: Optional[int] = None
    pain_score: Optional[int] = None
    notes: Optional[str] = None


def serialize_patient(p) -> dict:
    return {
        "id": p.id, "patient_id": p.patient_id, "full_name": p.full_name,
        "date_of_birth": p.date_of_birth.isoformat() if p.date_of_birth else None,
        "gender": p.gender, "blood_type": p.blood_type,
        "contact_phone": p.contact_phone, "contact_email": p.contact_email,
        "address": p.address, "allergies": p.allergies,
        "chronic_conditions": p.chronic_conditions, "current_medications": p.current_medications,
        "status": p.status, "ward": p.ward, "bed_number": p.bed_number,
        "attending_doctor_id": p.attending_doctor_id,
        "admission_date": p.admission_date.isoformat() if p.admission_date else None,
        "created_at": p.created_at.isoformat() if p.created_at else None,
    }


@router.post("/", status_code=201)
async def create_patient(
    body: PatientCreate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_permission(Permission.PATIENT_CREATE))
):
    patient = await PatientService.create(db, body.dict(), created_by_id=current_user.id)
    return {"message": "Patient created", "patient": serialize_patient(patient)}


@router.get("/")
async def list_patients(
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    search: Optional[str] = None,
    status: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_permission(Permission.PATIENT_VIEW))
):
    patients, total = await PatientService.list_patients(db, skip, limit, search, status)
    return {"total": total, "skip": skip, "limit": limit,
            "patients": [serialize_patient(p) for p in patients]}


@router.get("/dashboard/stats")
async def dashboard_stats(
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_permission(Permission.SYSTEM_STATS))
):
    return await PatientService.get_dashboard_stats(db)


@router.get("/{patient_id}")
async def get_patient(
    patient_id: int,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_permission(Permission.PATIENT_VIEW))
):
    patient = await PatientService.get_by_id(db, patient_id)
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")
    await AuditService.log(db, action="patient.view", user_id=current_user.id,
                           resource_type="patient", resource_id=str(patient_id))
    return serialize_patient(patient)


@router.post("/{patient_id}/vitals", status_code=201)
async def record_vitals(
    patient_id: int,
    body: VitalSignCreate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_permission(Permission.VITALS_RECORD))
):
    vital = await PatientService.record_vitals(
        db, patient_id, body.dict(exclude_none=True), current_user.id
    )
    result = {"vital_id": vital.id, "is_critical": vital.is_critical, "ai_triggered": False}

    # Only doctors and admins trigger AI on vitals
    from app.core.permissions import has_permission
    if has_permission(current_user.role, Permission.AI_ASSESS):
        try:
            assessment = await AIService.run_full_assessment(db, patient_id, current_user.id)
            result["ai_triggered"]  = True
            result["risk_level"]    = assessment["risk_assessment"]["risk_level"]
            result["risk_score"]    = assessment["risk_assessment"]["risk_score"]
        except Exception:
            pass
    return result


@router.get("/{patient_id}/vitals")
async def get_vitals(
    patient_id: int,
    limit: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_permission(Permission.VITALS_VIEW))
):
    vitals = await PatientService.get_patient_vitals(db, patient_id, limit)
    return {"patient_id": patient_id,
            "vitals": [{c.name: getattr(v, c.name) for c in v.__table__.columns} for v in vitals]}


@router.get("/{patient_id}/audit-trail")
async def get_audit_trail(
    patient_id: int,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_permission(Permission.AUDIT_VIEW_OWN))
):
    logs = await AuditService.get_patient_audit_trail(db, patient_id)
    return {"patient_id": patient_id,
            "audit_trail": [{"id": l.id, "action": l.action, "user_id": l.user_id,
                              "timestamp": l.timestamp.isoformat(), "status": l.status}
                            for l in logs]}
