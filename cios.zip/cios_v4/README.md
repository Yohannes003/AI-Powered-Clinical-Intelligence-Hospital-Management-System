# 🏥 CIOS — Clinical Intelligence Operating System

A production-grade, AI-native hospital ERP with real-time decision support, explainable AI, and clinical digital twins.

## Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│                    React Dashboard                       │
│              (Doctor / Admin Interface)                  │
└────────────────────────┬────────────────────────────────┘
                         │ HTTP/WS
┌────────────────────────▼────────────────────────────────┐
│                    API Gateway                           │
│           JWT Auth + RBAC + Rate Limiting               │
└──┬─────────────┬──────────────┬──────────────┬──────────┘
   │             │              │              │
┌──▼──┐    ┌────▼────┐    ┌────▼────┐   ┌────▼────┐
│ Pat │    │Clinical │    │ Report  │   │  Audit  │
│ Svc │    │  Svc    │    │   Svc   │   │   Svc   │
└──┬──┘    └────┬────┘    └────┬────┘   └────┬────┘
   │             │              │              │
┌──▼─────────────▼──────────────▼──────────────▼──────────┐
│                    Event Bus (Kafka-ready)                │
│    patient_created | diagnosis_added | lab_updated       │
└────────────────────────┬────────────────────────────────┘
                         │
┌────────────────────────▼────────────────────────────────┐
│                   AI Engine (Core)                       │
│    Risk Prediction | Anomaly Detection | XAI | Twins    │
└────────────────────────┬────────────────────────────────┘
                         │
┌────────────────────────▼────────────────────────────────┐
│              PostgreSQL + TimescaleDB                    │
└─────────────────────────────────────────────────────────┘
```

## Quick Start

### Prerequisites
- Docker & Docker Compose
- Node.js 18+
- Python 3.11+

### Run with Docker (Recommended)
```bash
cd cios
docker-compose up --build
```

### Manual Setup
```bash
# Backend
cd backend
pip install -r requirements.txt
cp .env.example .env  # Edit with your settings
alembic upgrade head
uvicorn app.main:app --reload --port 8000

# Frontend
cd frontend
npm install
npm start
```

## Services
| Service | Port | Description |
|---------|------|-------------|
| Frontend | 3000 | React Dashboard |
| API Gateway | 8000 | FastAPI Backend |
| PostgreSQL | 5432 | Primary Database |
| Redis | 6379 | Cache + Pub/Sub |

## API Docs
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## Default Credentials
- Admin: `admin@cios.hospital` / `Admin@123`
- Doctor: `doctor@cios.hospital` / `Doctor@123`
