import axios from 'axios';

const BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const api = axios.create({
  baseURL: `${BASE_URL}/api/v1`,
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' },
});

// Attach JWT to every request
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('cios_token');
    if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
  },
  (error) => Promise.reject(error)
);

// Auto-logout on 401
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('cios_token');
      localStorage.removeItem('cios_user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// ─── Auth ────────────────────────────────────────────────
export const authAPI = {
  login:    (email, password) => api.post('/auth/login', { email, password }),
  register: (data)            => api.post('/auth/register', data),
  me:       ()                => api.get('/auth/me'),
};

// ─── Patients ────────────────────────────────────────────
export const patientAPI = {
  list:         (params) => api.get('/patients/', { params }),
  get:          (id)     => api.get(`/patients/${id}`),
  create:       (data)   => api.post('/patients/', data),
  stats:        ()       => api.get('/patients/dashboard/stats'),
  recordVitals: (id, data) => api.post(`/patients/${id}/vitals`, data),
  getVitals:    (id, limit = 20) => api.get(`/patients/${id}/vitals`, { params: { limit } }),
  getAuditTrail:(id) => api.get(`/patients/${id}/audit-trail`),
};

// ─── Clinical ────────────────────────────────────────────
export const clinicalAPI = {
  addDiagnosis:     (data)      => api.post('/clinical/diagnoses', data),
  getDiagnoses:     (patientId) => api.get(`/clinical/diagnoses/${patientId}`),
  addLab:           (data)      => api.post('/clinical/labs', data),
  getLabs:          (patientId) => api.get(`/clinical/labs/${patientId}`),
  getAlerts:        (patientId, unackOnly = false) =>
    api.get(`/clinical/alerts/${patientId}`, { params: { unacknowledged_only: unackOnly } }),
  acknowledgeAlert: (alertId)   => api.post(`/clinical/alerts/${alertId}/acknowledge`),
};

// ─── AI ──────────────────────────────────────────────────
export const aiAPI = {
  assess:          (patientId)  => api.post(`/ai/assess/${patientId}`),
  getPredictions:  (patientId)  => api.get(`/ai/predictions/${patientId}`),
  getDigitalTwin:  (patientId)  => api.get(`/ai/digital-twin/${patientId}`),
  getPendingReviews: ()         => api.get('/ai/pending-reviews'),
  submitReview:    (predictionId, notes) =>
    api.post(`/ai/review/${predictionId}`, { review_notes: notes }),
};

// ─── Reports ─────────────────────────────────────────────
export const reportAPI = {
  generate: (data)     => api.post('/reports/generate', data),
  list:     (patientId) => api.get('/reports/', { params: { patient_id: patientId } }),

  // Returns a URL that includes the JWT token so the browser
  // can download the file directly without an Authorization header
  downloadUrl: (reportId) => {
    const token = localStorage.getItem('cios_token');
    return `${BASE_URL}/api/v1/reports/download/${reportId}/token?token=${token}`;
  },
};

export default api;
