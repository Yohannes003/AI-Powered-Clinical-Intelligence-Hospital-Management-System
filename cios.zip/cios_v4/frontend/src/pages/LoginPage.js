import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import toast from 'react-hot-toast';

export default function LoginPage() {
  const [email, setEmail] = useState('doctor@cios.hospital');
  const [password, setPassword] = useState('Doctor@123');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    const result = await login(email, password);
    setLoading(false);
    if (result.success) {
      toast.success('Welcome to CIOS');
      navigate('/');
    } else {
      toast.error(result.error);
    }
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: 'radial-gradient(ellipse at 20% 50%, #0B1E3D 0%, #060E1A 60%, #030810 100%)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: "'DM Sans', 'Segoe UI', sans-serif",
    }}>
      {/* Grid background */}
      <div style={{
        position: 'fixed', inset: 0, opacity: 0.05,
        backgroundImage: 'linear-gradient(#0EA5E9 1px, transparent 1px), linear-gradient(90deg, #0EA5E9 1px, transparent 1px)',
        backgroundSize: '40px 40px',
      }} />

      <div style={{
        width: 420, padding: 40,
        background: 'linear-gradient(135deg, #0B1E3D, #071428)',
        border: '1px solid #0EA5E930',
        borderRadius: 20,
        boxShadow: '0 25px 80px #000000A0, 0 0 40px #0EA5E910',
        position: 'relative', zIndex: 1,
      }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <div style={{
            width: 64, height: 64, borderRadius: 18,
            background: 'linear-gradient(135deg, #0EA5E9, #6366F1)',
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 32, marginBottom: 12,
            boxShadow: '0 8px 24px #0EA5E940',
          }}>🏥</div>
          <h1 style={{ color: '#F1F5F9', fontSize: 24, fontWeight: 700, margin: 0 }}>CIOS</h1>
          <p style={{ color: '#64748B', fontSize: 13, margin: '4px 0 0', letterSpacing: '1px' }}>
            CLINICAL INTELLIGENCE OPERATING SYSTEM
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          {[
            { label: 'Email', value: email, setter: setEmail, type: 'email', icon: '✉️' },
            { label: 'Password', value: password, setter: setPassword, type: 'password', icon: '🔒' },
          ].map(({ label, value, setter, type, icon }) => (
            <div key={label} style={{ marginBottom: 16 }}>
              <label style={{ color: '#94A3B8', fontSize: 12, fontWeight: 600, display: 'block', marginBottom: 6, letterSpacing: '0.5px' }}>
                {label.toUpperCase()}
              </label>
              <div style={{ position: 'relative' }}>
                <span style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', fontSize: 14 }}>{icon}</span>
                <input
                  type={type} value={value} onChange={e => setter(e.target.value)} required
                  style={{
                    width: '100%', padding: '11px 12px 11px 36px', borderRadius: 10,
                    background: '#060E1A', border: '1px solid #0EA5E925',
                    color: '#F1F5F9', fontSize: 14, outline: 'none',
                    boxSizing: 'border-box',
                    transition: 'border-color 0.15s',
                  }}
                  onFocus={e => e.target.style.borderColor = '#0EA5E9'}
                  onBlur={e => e.target.style.borderColor = '#0EA5E925'}
                />
              </div>
            </div>
          ))}

          <button type="submit" disabled={loading}
            style={{
              width: '100%', padding: '13px', borderRadius: 10,
              background: loading ? '#0EA5E940' : 'linear-gradient(135deg, #0EA5E9, #6366F1)',
              color: '#fff', fontWeight: 700, fontSize: 15,
              border: 'none', cursor: loading ? 'not-allowed' : 'pointer',
              marginTop: 8, letterSpacing: '0.3px',
              transition: 'all 0.2s',
            }}>
            {loading ? 'Authenticating...' : 'Sign In to CIOS'}
          </button>
        </form>

        <div style={{ marginTop: 24, padding: 16, background: '#0EA5E908', borderRadius: 10, border: '1px solid #0EA5E915' }}>
          <p style={{ color: '#475569', fontSize: 11, margin: 0, lineHeight: 1.6 }}>
            <strong style={{ color: '#64748B' }}>Demo credentials:</strong><br />
            Admin: admin@cios.hospital / Admin@123<br />
            Doctor: doctor@cios.hospital / Doctor@123
          </p>
        </div>
      </div>
    </div>
  );
}
