import React, { useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

const navItems = [
  { to: '/', label: 'Dashboard', icon: '⬡' },
  { to: '/patients', label: 'Patients', icon: '👤' },
  { to: '/ai-insights', label: 'AI Insights', icon: '🧠' },
  { to: '/reports', label: 'Reports', icon: '📊' },
];

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);

  const handleLogout = () => { logout(); navigate('/login'); };

  return (
    <div style={{ display: 'flex', height: '100vh', background: '#060E1A', fontFamily: "'DM Sans', 'Segoe UI', sans-serif", overflow: 'hidden' }}>
      {/* Sidebar */}
      <aside style={{
        width: collapsed ? 64 : 240,
        background: 'linear-gradient(180deg, #0B1E3D 0%, #071428 100%)',
        borderRight: '1px solid #0EA5E920',
        display: 'flex', flexDirection: 'column',
        transition: 'width 0.25s ease', flexShrink: 0,
      }}>
        {/* Logo */}
        <div style={{ padding: '20px 16px', borderBottom: '1px solid #0EA5E915', display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            width: 36, height: 36, borderRadius: 10,
            background: 'linear-gradient(135deg, #0EA5E9, #6366F1)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 18, flexShrink: 0
          }}>🏥</div>
          {!collapsed && (
            <div>
              <div style={{ color: '#F1F5F9', fontWeight: 700, fontSize: 15, letterSpacing: '0.3px' }}>CIOS</div>
              <div style={{ color: '#64748B', fontSize: 10, letterSpacing: '1px' }}>CLINICAL OS</div>
            </div>
          )}
          <button onClick={() => setCollapsed(c => !c)}
            style={{ marginLeft: 'auto', background: 'none', border: 'none', color: '#475569', cursor: 'pointer', fontSize: 16 }}>
            {collapsed ? '→' : '←'}
          </button>
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, padding: '12px 8px' }}>
          {navItems.map(({ to, label, icon }) => (
            <NavLink key={to} to={to} end={to === '/'}
              style={({ isActive }) => ({
                display: 'flex', alignItems: 'center', gap: 12,
                padding: '10px 12px', borderRadius: 8, marginBottom: 2,
                textDecoration: 'none', transition: 'all 0.15s',
                background: isActive ? 'linear-gradient(90deg, #0EA5E920, #6366F110)' : 'transparent',
                color: isActive ? '#38BDF8' : '#94A3B8',
                borderLeft: isActive ? '2px solid #0EA5E9' : '2px solid transparent',
                fontWeight: isActive ? 600 : 400, fontSize: 14,
              })}>
              <span style={{ fontSize: 18, flexShrink: 0 }}>{icon}</span>
              {!collapsed && label}
            </NavLink>
          ))}
        </nav>

        {/* User */}
        <div style={{ padding: '12px 8px', borderTop: '1px solid #0EA5E915' }}>
          {!collapsed && (
            <div style={{ padding: '8px 12px', marginBottom: 8 }}>
              <div style={{ color: '#CBD5E1', fontSize: 13, fontWeight: 600 }}>{user?.full_name}</div>
              <div style={{ color: '#475569', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.5px' }}>{user?.role}</div>
            </div>
          )}
          <button onClick={handleLogout}
            style={{
              width: '100%', padding: '8px 12px', borderRadius: 8, border: 'none',
              background: '#DC262615', color: '#F87171', cursor: 'pointer',
              fontSize: 13, display: 'flex', alignItems: 'center', gap: 8,
            }}>
            <span>🚪</span>{!collapsed && 'Sign Out'}
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main style={{ flex: 1, overflow: 'auto', background: '#060E1A' }}>
        {/* Topbar */}
        <div style={{
          height: 56, background: '#0B1E3D90', backdropFilter: 'blur(12px)',
          borderBottom: '1px solid #0EA5E915',
          display: 'flex', alignItems: 'center', padding: '0 24px',
          position: 'sticky', top: 0, zIndex: 10,
        }}>
          <div style={{ color: '#64748B', fontSize: 12 }}>
            {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </div>
          <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{
              padding: '4px 12px', borderRadius: 20,
              background: '#22C55E15', color: '#4ADE80',
              border: '1px solid #22C55E30', fontSize: 11, fontWeight: 600,
            }}>● SYSTEM OPERATIONAL</div>
          </div>
        </div>

        {/* Page content */}
        <div style={{ padding: '24px', minHeight: 'calc(100vh - 56px)' }}>
          <Outlet />
        </div>
      </main>
    </div>
  );
}
