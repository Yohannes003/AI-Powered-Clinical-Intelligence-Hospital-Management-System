from fastapi import APIRouter, Depends, HTTPException, status, Request
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel, EmailStr
from typing import Optional

from app.db.session import get_db
from app.services.user_service import UserService
from app.core.security import create_access_token, create_refresh_token, get_current_user
from app.audit.audit_service import AuditService

router = APIRouter(prefix="/auth", tags=["Authentication"])


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class RegisterRequest(BaseModel):
    email: EmailStr
    full_name: str
    password: str
    role: str = "doctor"
    department: Optional[str] = None
    license_number: Optional[str] = None


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    user: dict


@router.post("/login", response_model=TokenResponse)
async def login(
    req: LoginRequest,
    request: Request,
    db: AsyncSession = Depends(get_db)
):
    user = await UserService.authenticate(db, req.email, req.password)
    if not user:
        await AuditService.log(
            db, action="auth.login.failed",
            resource_type="user", resource_id=req.email,
            request=request, status="failed",
            error_message="Invalid credentials"
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password"
        )

    access_token = create_access_token({"sub": str(user.id), "role": user.role})
    refresh_token = create_refresh_token({"sub": str(user.id)})

    await AuditService.log(
        db, action="auth.login.success",
        user_id=user.id,
        resource_type="user", resource_id=str(user.id),
        request=request
    )

    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        user={
            "id": user.id,
            "email": user.email,
            "full_name": user.full_name,
            "role": user.role,
            "department": user.department,
        }
    )


@router.post("/register", status_code=201)
async def register(req: RegisterRequest, db: AsyncSession = Depends(get_db)):
    existing = await UserService.get_by_email(db, req.email)
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    user = await UserService.create(db, req.dict())
    access_token = create_access_token({"sub": str(user.id), "role": user.role})

    return {
        "message": "User registered successfully",
        "access_token": access_token,
        "user": {"id": user.id, "email": user.email, "full_name": user.full_name, "role": user.role}
    }


@router.get("/me")
async def get_me(current_user=Depends(get_current_user)):
    return {
        "id": current_user.id,
        "email": current_user.email,
        "full_name": current_user.full_name,
        "role": current_user.role,
        "department": current_user.department,
        "license_number": current_user.license_number,
        "is_active": current_user.is_active,
    }
